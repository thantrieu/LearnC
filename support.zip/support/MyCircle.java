package support;

public class MyCircle {
    private int radius;
    private MyPoint center;

    public MyCircle() {
    }

    public MyCircle(int radius, MyPoint center) {
        this.radius = radius;
        this.center = center;
    }
}
